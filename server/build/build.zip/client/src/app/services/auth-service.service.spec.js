"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const testing_1 = require("@angular/core/testing");
const auth_service_service_1 = require("./auth-service.service");
describe('AuthServiceService', () => {
    let service;
    beforeEach(() => {
        testing_1.TestBed.configureTestingModule({});
        service = testing_1.TestBed.inject(auth_service_service_1.AuthServiceService);
    });
    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
