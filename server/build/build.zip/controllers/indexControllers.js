"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.indexController = void 0;
const path_1 = __importDefault(require("path"));
class IndexController {
    index(req, res) {
        // res.json({text: 'API is /api/instalaciones'});
        res.sendFile(path_1.default.join(__dirname, './../view/index.html'));
    }
}
exports.indexController = new IndexController();
