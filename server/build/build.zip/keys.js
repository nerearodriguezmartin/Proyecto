"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    database: {
        host: 'proyecto.cz9wwzqsqghe.eu-west-3.rds.amazonaws.com',
        user: 'admin',
        password: 'password',
        database: 'sobway'
    }
};
